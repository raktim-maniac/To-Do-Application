var num = 0;
var LIST = [];
function addCard() {
  let myDiv = document.createElement("div");
  let myPara = document.createElement("p");
  let myBtn = document.createElement("button");

  myDiv.setAttribute("class", "card");
  myBtn.setAttribute("type", "button");
  myBtn.setAttribute("id", `${num}`);
  myBtn.setAttribute("onclick", "removeCard(this.id)");

  const inputBox = document.getElementById("inputTodo");
  const inputDiv = document.getElementById("addInput");

  let item = inputBox.value;
  //   LIST[num] = item;
  //   sessionStorage.getItem("TODO", JSON.stringify(LIST));

  myPara.textContent = item;
  myBtn.textContent = "Done";

  myDiv.appendChild(myPara);
  myDiv.appendChild(myBtn);

  document.getElementById("todo-list").insertBefore(myDiv, inputDiv);

  inputBox.value = "";
  num++;
}

function removeCard(clickedId) {
  const clickedBtn = document.getElementById(clickedId);
  const doneTodo = clickedBtn.parentNode.firstChild.textContent;
  let myDiv = document.createElement("div");
  let myPara = document.createElement("p");

  myDiv.setAttribute("class", "card");
  myPara.textContent = doneTodo;
  myDiv.appendChild(myPara);

  document.getElementById("done-todo-list").appendChild(myDiv);

  clickedBtn.parentNode.remove();
}

function resetDone() {
  var e = document.getElementById("done-todo-list");
  var child = e.lastElementChild;
  while (child) {
    e.removeChild(child);
    child = e.lastElementChild;
  }
}

myAddButton = document.getElementById("addButton");
myAddButton.addEventListener("click", addCard);

resetButton = document.getElementById("resetButton");
resetButton.addEventListener("click", resetDone);
